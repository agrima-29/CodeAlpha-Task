#include <stdio.h>
#include <string.h>
#include <conio.h>

struct Book {
    char name[30];
    int book_number;
    char author[30];
    char genre[20];
    int book_count;
};

struct Member {
    char username[15];
    char password[15];
    int issued_books[5];
    int book_counter;
    int issue_date[5][3];
};

struct Book books[50] = {
    {"Business correspondence and report writing", 0, "Krishna Mohan", "Education", 0},
    {"The Diary of a Young Girl", 1, "Anne Frank", "Autobiography", 8},
    {"Lehninger Principles of Biochemistry", 2, "Albert L. Lehninger", "Science", 2},
    {"Mathematics", 3, "R S Agarwal", "Education", 3},
    {"World War 2", 4, "Andrew Roberts", "History", 2},
    {"A Song of Ice and Fire", 5, "George R.R. Martin", "Fiction", 1},
    {"It Ends with Us", 6, "Colleen Hoover", "Fiction", 0},
    {"Diary of a Wimpy Kid", 7, "Jeff Kinney", "Fiction", 1},
    {"Rich Dad Poor Dad", 8, "Robert Kiyosaki", "Nonfiction", 3},
    {"How to Win Friends and Influence People", 9, "Dale Carnegie", "Self-Help", 3}
};

struct Member members[500] = {
    {"flush", "flush", {0}, 0, {0}},
    {"nis31032003", "googlegmail", {0}, 0, {0}},
};

int member_count = 2;

void display_home();
void login();
void new_member_signup();
void display_rules();
void display_about();
void issue_book(struct Member *member);
void return_book(struct Member *member);
void customer_portal(struct Member *member);
void display_issued_books(struct Member *member);
void search_books();
void request_book(struct Member *member);

int main() {
    while (1) {
        display_home();
    }
    return 0;
}

void display_home() {
    int choice;
    printf("\n\t\t\t\t\t  LIBRARY PORTAL \n\n");
    printf(" \t\t\t\t\tLogin\t\t\t\t press 1\n");
    printf(" \t\t\t\t\tRules Of The Library\t press 2\n");
    printf(" \t\t\t\t\tNew Member Signup\t press 3\n");
    printf(" \t\t\t\t\tLost and Found\t\t press 4\n");
    printf(" \t\t\t\t\tAbout The Program\t press 5\n");
    scanf("%d", &choice);

    switch (choice) {
        case 1: login(); break;
        case 2: display_rules(); break;
        case 3: new_member_signup(); break;
        case 4: printf("Lost and Found section\n"); break;
        case 5: display_about(); break;
        default: printf("Invalid choice, try again.\n");
    }
}

void login() {
    int login_type, i;
    char username[30], password[15];
    
    printf(" Administration login\t press 1\n Customer login\t\t press 2\n");
    scanf("%d", &login_type);

    printf("Username: ");
    scanf("%s", username);
    printf("Password: ");
    scanf("%s", password);

    if (login_type == 1) {
        if (strcmp(username, "admin") == 0 && strcmp(password, "admin.main") == 0) {
            printf("Admin login successful!\n");
        } else {
            printf("Invalid admin credentials\n");
        }
    } else if (login_type == 2) {
        for (i = 0; i < member_count; i++) {
            if (strcmp(members[i].username, username) == 0 && strcmp(members[i].password, password) == 0) {
                printf("Customer login successful!\n");
                customer_portal(&members[i]);
                return;
            }
        }
        printf("Invalid customer credentials\n");
    }
}

void new_member_signup() {
    char username[15], password[15], re_password[15];
    printf("New Username: ");
    scanf("%s", username);
    do {
        printf("Password: ");
        scanf("%s", password);
        printf("Re-enter Password: ");
        scanf("%s", re_password);
        if (strcmp(password, re_password) != 0) {
            printf("Passwords do not match, try again.\n");
        }
    } while (strcmp(password, re_password) != 0);

    strcpy(members[member_count].username, username);
    strcpy(members[member_count].password, password);
    members[member_count].book_counter = 0;
    member_count++;
    printf("Signup successful!\n");
}

void display_rules() {
    printf("Library Rules:\n");
    printf("1. Maintain silence inside the library.\n");
    printf("2. Handle books with care.\n");
    printf("3. Return books on time.\n");
    printf("4. Report any damage or loss of books immediately.\n");
    printf("5. Keep your belongings with you at all times.\n");
}

void display_about() {
    printf("About the Program:\n");
    printf("This is a simple library management system implemented in C. It supports functionalities such as login, book issuance, book return, and more.\n");
}

void customer_portal(struct Member *member) {
    int choice;
    printf(" \n                          Issued books              Press 1");
    printf(" \n                          Book Search               Press 2");
    printf(" \n                          Book Request Portal       Press 3");
    printf(" \n                          Return Book               Press 4\n");
    printf(" \n\n                          To return to the home page press 0\n");
    scanf("%d", &choice);

    switch (choice) {
        case 1: 
            display_issued_books(member);
            break;
        case 2: 
            search_books();
            break;
        case 3: 
            request_book(member);
            break;
        case 4: 
            return_book(member);
            break;
        case 0: 
            return;
        default: 
            printf("Invalid choice, try again.\n");
    }
}

void display_issued_books(struct Member *member) {
    printf("Issued books:\n");
    for (int i = 0; i < member->book_counter; i++) {
        printf("%d. %s\n", i + 1, books[member->issued_books[i]].name);
    }
}

void search_books() {
    char search_term[30];
    printf("Enter book name to search: ");
    scanf("%s", search_term);
    for (int i = 0; i < 10; i++) {
        if (strstr(books[i].name, search_term)) {
            printf("Book Found: %s by %s\n", books[i].name, books[i].author);
        }
    }
}

void request_book(struct Member *member) {
    int book_number;
    printf("Enter book number to request: ");
    scanf("%d", &book_number);
    if (books[book_number].book_count > 0 && member->book_counter < 5) {
        books[book_number].book_count--;
        member->issued_books[member->book_counter] = book_number;
        member->book_counter++;
        printf("Book requested successfully.\n");
    } else {
        printf("Book cannot be requested. Either out of stock or issue limit reached.\n");
    }
}

void issue_book(struct Member *member) {
    int book_number, day, month, year;
    printf("Enter book number to issue: ");
    scanf("%d", &book_number);
    if (books[book_number].book_count > 0 && member->book_counter < 5) {
        printf("Enter issue date (dd mm yyyy): ");
        scanf("%d %d %d", &day, &month, &year);
        books[book_number].book_count--;
        member->issued_books[member->book_counter] = book_number;
        member->issue_date[member->book_counter][0] = day;
        member->issue_date[member->book_counter][1] = month;
        member->issue_date[member->book_counter][2] = year;
        member->book_counter++;
        printf("Book issued successfully.\n");
    } else {
        printf("Book cannot be issued. Either out of stock or issue limit reached.\n");
    }
}

void return_book(struct Member *member) {
    int book_number, i, found = 0;
    printf("Enter book number to return: ");
    scanf("%d", &book_number);
    for (i = 0; i < member->book_counter; i++) {
        if (member->issued_books[i] == book_number) {
            found = 1;
            break;
        }
    }
    if (found) {
        books[book_number].book_count++;
        for (i = i; i < member->book_counter - 1; i++) {
            member->issued_books[i] = member->issued_books[i + 1];
            member->issue_date[i][0] = member->issue_date[i + 1][0];
            member->issue_date[i][1] = member->issue_date[i + 1][1];
            member->issue_date[i][2] = member->issue_date[i + 1][2];
        }
        member->book_counter--;
        printf("Book returned successfully.\n");
    } else {
        printf("Book not found in your issued books.\n");
    }
}
