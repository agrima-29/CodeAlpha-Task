#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <openssl/sha.h> // Added for secure hashing
#include <stdlib.h>      // Added for memory allocation

#define MAX_MEMBERS 500
#define MAX_BOOKS 50

struct Book {
    char name[30];
    int book_number;
    char author[30];
    char genre[20];
    int book_count;
};

struct Member {
    char username[15];
    unsigned char password_hash[SHA256_DIGEST_LENGTH]; // Changed to store hashed passwords
    int issued_books[5];
    int book_counter;
    int issue_date[5][3];
};

// Define book and member arrays with a constant size
struct Book books[MAX_BOOKS] = {
    {"Business correspondence and report writing", 0, "Krishna Mohan", "Education", 0},
    {"The Diary of a Young Girl", 1, "Anne Frank", "Autobiography", 8},
    {"Lehninger Principles of Biochemistry", 2, "Albert L. Lehninger", "Science", 2},
    {"Mathematics", 3, "R S Agarwal", "Education", 3},
    {"World War 2", 4, "Andrew Roberts", "History", 2},
    {"A Song of Ice and Fire", 5, "George R.R. Martin", "Fiction", 1},
    {"It Ends with Us", 6, "Colleen Hoover", "Fiction", 0},
    {"Diary of a Wimpy Kid", 7, "Jeff Kinney", "Fiction", 1},
    {"Rich Dad Poor Dad", 8, "Robert Kiyosaki", "Nonfiction", 3},
    {"How to Win Friends and Influence People", 9, "Dale Carnegie", "Self-Help", 3}
};

struct Member members[MAX_MEMBERS] = {
    {"flush", {0}, {0}, 0, {0}},
    {"nis31032003", {0}, {0}, 0, {0}}
};

int member_count = 2;

void display_home();
void login();
void new_member_signup();
void display_rules();
void display_about();
void issue_book(struct Member *member);
void return_book(struct Member *member);
void customer_portal(struct Member *member);
void display_issued_books(struct Member *member);
void search_books();
void request_book(struct Member *member);
void hash_password(const char *password, unsigned char *output); // Added function for hashing
void get_password(char *password, size_t size); // Added function for secure password input

int main() {
    while (1) {
        display_home();
    }
    return 0;
}

void display_home() {
    int choice;
    printf("\n\t\t\t\t\t  LIBRARY PORTAL \n\n");
    printf(" \t\t\t\t\tLogin\t\t\t\t press 1\n");
    printf(" \t\t\t\t\tRules Of The Library\t press 2\n");
    printf(" \t\t\t\t\tNew Member Signup\t press 3\n");
    printf(" \t\t\t\t\tLost and Found\t\t press 4\n");
    printf(" \t\t\t\t\tAbout The Program\t press 5\n");
    scanf("%d", &choice); 

    switch (choice) {
        case 1: login(); break;
        case 2: display_rules(); break;
        case 3: new_member_signup(); break;
        case 4: printf("Lost and Found section\n"); break;
        case 5: display_about(); break;
        default: printf("Invalid choice, try again.\n");
    }
}

void hash_password(const char *password, unsigned char *output) {
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, password, strlen(password));
    SHA256_Final(output, &sha256);
}

// Securely get password input and mask it
void get_password(char *password, size_t size) {
    int i = 0;
    char ch;
    while (i < size - 1 && (ch = _getch()) != '\r') {
        if (ch == '\b') {
            if (i > 0) {
                i--;
                printf("\b \b");
            }
        } else {
            password[i++] = ch;
            printf("*");
        }
    }
    password[i] = '\0';
    printf("\n");
}

void login() {
    int login_type, i, attempts = 3;
    char username[30], password[15];
    unsigned char password_hash[SHA256_DIGEST_LENGTH];

    printf(" Administration login\t press 1\n Customer login\t\t press 2\n");
    scanf("%d", &login_type); 

    while (attempts > 0) {
        printf("Username: ");
        scanf("%s", username); 
        printf("Password: ");
        get_password(password, sizeof(password)); // Used secure password input
        hash_password(password, password_hash); // Hash the password

        if (login_type == 1) {
            if (strcmp(username, "admin") == 0 && memcmp(password_hash, members[0].password_hash, SHA256_DIGEST_LENGTH) == 0) {
                printf("Admin login successful!\n");
                return;
            } else {
                printf("Invalid admin credentials\n");
            }
        } else if (login_type == 2) {
            for (i = 0; i < member_count; i++) {
                if (strcmp(members[i].username, username) == 0 && memcmp(password_hash, members[i].password_hash, SHA256_DIGEST_LENGTH) == 0) {
                    printf("Customer login successful!\n");
                    customer_portal(&members[i]);
                    return;
                }
            }
            printf("Invalid customer credentials\n");
        }
        attempts--;
        printf("Remaining attempts: %d\n", attempts);
    }
    printf("Too many failed login attempts. Please try again later.\n");
}

void new_member_signup() {
    char username[15], password[15], re_password[15];
    unsigned char password_hash[SHA256_DIGEST_LENGTH];
    printf("New Username: ");
    scanf("%s", username); 
    do {
        printf("Password: ");
        get_password(password, sizeof(password)); // Used secure password input
        printf("Re-enter Password: ");
        get_password(re_password, sizeof(re_password)); // Used secure password input
        if (strcmp(password, re_password) != 0) {
            printf("Passwords do not match, try again.\n");
        }
    } while (strcmp(password, re_password) != 0);

    strcpy(members[member_count].username, username); 
    hash_password(password, password_hash); // Hash the password
    memcpy(members[member_count].password_hash, password_hash, SHA256_DIGEST_LENGTH); // Store the hashed password
    members[member_count].book_counter = 0;
    member_count++;
    printf("Signup successful!\n");
}

void display_rules() {
    printf("Library Rules:\n");
    printf("1. Maintain silence inside the library.\n");
    printf("2. Handle books with care.\n");
    printf("3. Return books on time.\n");
    printf("4. Report any damage or loss of books immediately.\n");
    printf("5. Keep your belongings with you at all times.\n");
}

void display_about() {
    printf("About the Program:\n");
    printf("This is a simple library management system implemented in C. It supports functionalities such as login, book issuance, book return, and more.\n");
}

void customer_portal(struct Member *member) {
    int choice;
    printf(" \n                          Issued books              Press 1");
    printf(" \n                          Book Search               Press 2");
    printf(" \n                          Book Request Portal       Press 3");
    printf(" \n                          Return Book               Press 4\n");
    printf(" \n\n                          To return to the home page press 0\n");
    scanf("%d", &choice); 

    switch (choice) {
        case 1: 
            display_issued_books(member);
            break;
        case 2: 
            search_books();
            break;
        case 3: 
            request_book(member);
            break;
        case 4: 
            return_book(member);
            break;
        case 0: 
            return;
        default: 
            printf("Invalid choice, try again.\n");
    }
}

void display_issued_books(struct Member *member) {
    printf("Issued books:\n");
    for (int i = 0; i < member->book_counter; i++) {
        printf("%d. %s\n", i + 1, books[member->issued_books[i]].name); s
    }
}

void search_books() {
    char search_term[30];
    printf("Enter book name to search: ");
    scanf("%s", search_term); 
    for (int i = 0; i < 10; i++) {
        if (strstr(books[i].name, search_term)) { 
            printf("Book Found: %s by %s\n", books[i].name, books[i].author); 
        }
    }
}

void request_book(struct Member *member) {
    char book_name[30];
    printf("Enter book name to request: ");
    scanf("%s", book_name); 
    printf("Request for the book '%s' has been placed.\n", book_name);
}

void return_book(struct Member *member) {
    int book_number;
    printf("Enter book number to return: ");
    scanf("%d", &book_number); 
    for (int i = 0; i < member->book_counter; i++) {
        if (member->issued_books[i] == book_number) {
            printf("Book '%s' returned successfully.\n", books[book_number].name);
            member->book_counter--;
            return;
        }
    }
    printf("No such book issued to you.\n");
}
